declare module Example.TeamMembers.Server {
	interface editViewModel {
		id?: any;
		name: string;
		teamId : string; 
        userId : string; 
        isManager : boolean;
	}
}
