declare module Example.Timesheets.Server {
	interface editViewModel {
		id?: any;
		weekDay: string;
		name: string;
	}
}
