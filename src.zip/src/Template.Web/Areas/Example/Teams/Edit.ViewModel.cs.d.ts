declare module Example.Teams.Server {
	interface editViewModel {
		id?: any;
		name: string;
	}
}
