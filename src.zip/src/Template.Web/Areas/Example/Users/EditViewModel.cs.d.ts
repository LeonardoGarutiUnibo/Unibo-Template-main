declare module Example.Users.Server {
	interface editViewModel {
		id?: any;
		email: string;
		firstName: string;
		lastName: string;
		nickName: string;
	}
}
