declare module Example.AbsenceEvents.Server {
	interface editViewModel {
		id?: any;
		UserId: string;
		RequestDate: string;
		StartEventDate : string; 
        EndDateEvent : string; 
        EventType : string;
		EventState : string;

	}
}
