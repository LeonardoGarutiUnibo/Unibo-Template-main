﻿using System.Threading.Tasks;

namespace Template.Web.SignalR
{
    public interface IPublishDomainEvents
    {
        Task Publish(object evnt);
    }
}
