﻿namespace Template.Web
{
    public class SharedResource
    {
    }
}